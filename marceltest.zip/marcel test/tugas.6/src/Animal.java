public class Animal {
 void walk () {
     System.out.println("Animal are walking");
 } 
}

class Cat extends Animal {
    public static void main(String[] args) {
        Cat cat = new Cat();
        cat.walk();
    }
         }