<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-
scale=1.0">

    <title>MyApp | Halaman Utama</title>
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">MyApp</a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">

                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">

                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">

                            <a class="nav-link" aria-current="page" href="#">Home</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link active" href="#"></a>

                        </li>
                    </ul>
                    <div class="row">
                        <div class="col d-flex justify-content-end mt-2">
                            <a href="?logout=true" class="btn btn-danger">Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
        <div class="row mt-3">
            <div class="col-sm">
                <h3>Tabel User</h3>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <a href="tambahUser.php" class="btn btn-primary btn-sm ml-2 mt-1    ">Tambah Data</a>
                <input type="text" class="form-control mt-3" id="searchInput" placeholder="Cari berdasarkan email...">
            </div>
        </div>
        <div class="row mt-3">
            <div class="col">
                <table class="table table-striped table-hover table-sm">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>ID User</th>
                            <th>Nama User</th>
                            <th>Jenis Kelamin</th>
                            <th>Email</th>
                            <th>Alamat</th>
                            <th>Password</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="userData">
                        <?php
                        include 'koneksi.php';
                        $no = 1;
                        $hasil = $koneksi->query("SELECT * FROM user");
                        ?>
                        <?php
                        while ($row = $hasil->fetch_assoc()) {
                        ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= $row['idUser']; ?></td>
                                <td><?= $row['nmUser']; ?></td>
                                <td><?= $row['jk']; ?></td>
                                <td><?= $row['email']; ?></td>
                                <td><?= $row['alamat']; ?></td>
                                <td><?= $row['password']; ?></td>
                                <td>
                                    <a href="editUser.php?edit=<?= $row['idUser']; ?>" class="btn btn-warning btn-sm">Edit</a> 
                                    <a href="koneksi.php?idUser=<?= $row['idUser']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- JavaScript for Search Functionality -->
    <script>
        document.getElementById("searchInput").addEventListener("keyup", function() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("searchInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("userData");
            tr = table.getElementsByTagName("tr");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[4]; // Mengambil kolom ke-5 (Email)
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        });
    </script>

</body>

</html>
