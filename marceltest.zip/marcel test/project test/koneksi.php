<?php
$koneksi = new mysqli('localhost', 'root', '', 'pasiencel')
or die(mysqli_error($koneksi));

if (isset($_POST['simpan'])) {
    $idUser = $_POST['idUser'];
    $nmUser = $_POST['nmUser'];
    $password = $_POST['password'];
    $jk = $_POST['jk'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];
    $koneksi->query("INSERT INTO User (idUser, nmUser, password, jk, email, alamat) VALUES ('$idUser', '$nmUser', '$password', '$jk', '$email', '$alamat')");

    header('location:User.php');
}
if (isset($_GET['idUser'])) {
    $idUser = $_GET['idUser'];
    $koneksi->query("DELETE FROM user WHERE idUser = '$idUser'");

    header('location:User.php');
}
if(isset($_POST['edit'])) {
    $idUser = $_POST['idUser'];
    $nmUser = $_POST['nmUser'];
    $password = $_POST['password'];
    $jk = $_POST['jk'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];
    $koneksi->query("UPDATE User SET idUser='$idUser', nmUser='$nmUser', password='$password', jk='$jk', email='$email', alamat='$alamat' WHERE idUser='$idUser'");
    
    header("location:User.php");
}

function logout() {
    // Hapus semua variabel sesi
    $_SESSION = array();

    // Hapus cookie sesi jika ada
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Hancurkan sesi
    session_destroy();

    // Redirect kembali ke index.php
    header("Location: index.php");
    exit();
}

// Panggil fungsi logout jika parameter 'logout' terdefinisi dalam URL
if (isset($_GET['logout'])) {
    logout();
}
?>