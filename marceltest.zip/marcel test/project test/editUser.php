<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-
scale=1.0">

    <title>Edit Data User</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            color: #343a40;
        }

        .container {
            margin-top: 50px;
        }

        h3 {
            color: #007bff;
            margin-bottom: 30px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-check-input {
            margin-top: 5px;
            margin-right: 10px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            width: 100%;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        label {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h3>Edit Data User</h3>
                <?php
                include 'koneksi.php';
                $panggil = $koneksi->query("SELECT * FROM user where idUser='$_GET[edit]'");
                ?>
                <?php
                while ($row = $panggil->fetch_assoc()) {
                ?>
                    <form action="koneksi.php" method="POST">
                        <div class="form-group">
                            <label for="idUser">ID User</label>
                            <input type="text" class="form-control" name="idUser" value="<?= $row['idUser'] ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="nmUser">Nama User</label>
                            <input type="text" class="form-control" name="nmUser" value="<?= $row['nmUser'] ?>">
                        </div>
                        <div class="form-group">
                            <label for="password">Password User</label>
                            <input type="text" class="form-control" name="password" value="<?= $row['password'] ?>">
                        </div>
                        <div class="form-group">
                            <label for="jk">Jenis Kelamin</label><br>
                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="jk" value="perempuan" <?php if (($row['jk']) === "perempuan") { echo "checked"; } ?>>
                                <label class="form-check-label" for="jk">Perempuan</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="jk" value="laki-laki" <?php if (($row['jk']) === "laki-laki") { echo "checked"; } ?>>
                                <label class="form-check-label" for="jk">Laki-laki</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" class="form-control" name="email" value="<?= $row['email'] ?>">
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <textarea class="form-control" name="alamat" id="alamat" cols="5" rows="3" placeholder="Alamat"><?= $row['alamat'] ?></textarea>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="edit" value="Edit" class="btn btn-primary">
                        </div>
                    </form>
                <?php } ?>
            </div>
        </div>
    </div>
</body>

</html>
