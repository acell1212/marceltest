#include <iostream>
#include <string>
#include <algorithm>
#include <cctype>

bool isAlphanumeric(char c) {
    return std::isalnum(static_cast<unsigned char>(c)) != 0;
}

bool isPalindrome(const std::string& str) {
    std::string temp;
    for (size_t i = 0; i < str.length(); ++i) {
        if (isAlphanumeric(str[i])) {
            temp += std::tolower(str[i]);
        }
    }
    
    std::string::iterator itr1 = temp.begin();
    std::string::iterator itr2 = temp.end() - 1;

    while (itr1 < itr2) {
        if (*itr1 != *itr2)
            return false;
        ++itr1;
        --itr2;
    }
    return true;
}

int main() {
    std::string input;
    std::cout << "Masukkan kata: ";
    std::getline(std::cin, input);

    if (isPalindrome(input))
        std::cout << "\"" << input << "\"" << " adalah palindrome.\n";
    else
        std::cout << "\"" << input << "\"" << " bukan palindrome.\n";

    return 0;
}

