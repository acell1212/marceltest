#include <iostream>
using namespace std;

void generateOddNumbers(int N) {
    int currentNumber = 1;
    for (int i = 0; i < N; ++i) {
        cout << currentNumber << " ";
        currentNumber += 2;
    }
}

int main() {
    int N;
    cout << "Masukkan nilai N: ";
    cin >> N;
    
    cout << "Bilangan ganjil pertama: ";
    generateOddNumbers(N);
    
    return 0;
}
